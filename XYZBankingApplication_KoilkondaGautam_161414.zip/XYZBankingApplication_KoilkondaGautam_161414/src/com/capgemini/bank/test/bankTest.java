package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


import org.junit.Test;
import org.junit.BeforeClass;



import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;


//Implementation of JUnit Testing 

public class bankTest {
	
	 static DemandDraftDAO dao;
	    static DemandDraft demanddraft;
	    
	    
	    @BeforeClass
	    public static void initialize() {
	        dao = new DemandDraftDAO();
	        demanddraft = new DemandDraft();
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails1() throws DemandDraftException {

	        assertNotNull(dao.addDraftDetails(demanddraft));
	    }
	    
	    
	    @Test
	    public void testAddDemandDraftDetails2() throws DemandDraftException {
	        assertEquals(10001, dao.addDraftDetails(demanddraft));
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails3() throws DemandDraftException {
	    	
	    	
	    	demanddraft.setCustomer_name("Gautam");
	    	demanddraft.setPhone_number("9087654321");
	    	demanddraft.setDd_amount(5500);
	    	demanddraft.setIn_favor_of("capgemini");
	    	demanddraft.setDd_description("salary");
	        assertTrue("Data Inserted successfully",
	                Integer.parseInt(dao.addDraftDetails(demanddraft)) > 10001);

	    }


}
